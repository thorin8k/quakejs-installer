----------------------------------------------------------------------------

QOMICAL QUAKE
A minor visual experiment by CannerZ45

----------------------------------------------------------------------------
Summary:
Pretty much inspired heavily from XIII, this mod is my limited attempt at
applying the "cel-shaded" visuals for Quake 3.

----------------------------------------------------------------------------
Installation:
Extract and place the whole "qomical" folder inside your Quake 3 Arena game
directory. It should be together with the "baseq3" folder, NOT INSIDE it.

Then, either run the batch file included in the mod folder(RunQ3Qomical.bat),
or create an exe shortcut, and add the given line below in the 'target'
dialog box;

 +set fs_game qomical +set sv_pure 1 +set com_hunkmegs 128

It should be placed after the written stuff in the target dialogue box, not
overwrite it.

----------------------------------------------------------------------------
Gameplay notes:
As you may have noticed on successful mod execution, the main menu
(and later, the in-game menu) has severely limited options. This is
because the mod(and its gameplay alterations) pretty much only caters
for SP-DM experience. I don't know how this mod will work with other
gamemodes and with multiple real players.

If you REALLY want to, you could setup an MP game(and invoke the other
gamemodes) via the console commands, but again, I can't ensure the
stability of this mod in MP and other gamemodes.

Also, I opt out VQ3A's way of adding bot. I'd setup the mod so that once in
game, it will automatically add random bots for you. What you can control
in the in-game menu is the max number of bots in the map.

As usual, the gameplay changes made here are based off of my previous base
gameplay mod.

----------------------------------------------------------------------------
The technical part:
Two major trick I did, was reusing the model draw
function(that is usually used in making the various
powerup aura effect) and making it call a customized
shader texture(solid black image map with no
light interaction), and by reworking the underutilized
shotgun sprite puff function(only used in creating smoke
in shotgun fire), to make the various comic style 
word/effects.

The biggest problem that I didn't manage to get over
is in implementing the actual "cel-shading". As I can't
do complicated math stuff and renderer codes. I could opt in
usingshader texture to fake a cel shade, but the big problem
on that one, is that i doesn't interact well with the weapon
models(it doesn't change with the player's view angle or map
position, ala Half-Life 1).